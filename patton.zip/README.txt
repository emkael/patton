Patton dla Team�w

Opis

Zestaw prostych narz�dzi (skrypt�w SQL) pozwalaj�cych na przeliczenie turnieju
team�w liczonego Pattonem, a za�o�onego w Teamach JFR.

Autor

Micha� Klichowicz (emkael.info)
Narz�dzia powsta�y na Bryd�owym Og�lnopolskim Obozie M�odzie�owym 2014,
pod nadzorem s�dziego g��wnego BOOMu - Czai.

Instalacja/u�ycie

1.  Za�o�y� turniej w JFR Teamach (do wyboru: BAM / IMP+VP)
1a. Dla turnieju IMP+VP wczyta� (w sumie dowoln�, ale mo�e by� do��czona,
    zdegenerowana) tabel� VP.
2.  Uruchomi� co najmniej raz odpowiedni skrypt SQL (dla turnieju za�o�onego
    jako BAM: patton-bam.sql; dla turnieju IMP+VP: patton-imp.sql) PRZED
	aplikacj� pierwszego wyr�wnania w turnieju.
3.  Uruchomi� skrypt ka�dorazowo dla przeliczenia wynik�w.

Licencja i dodatkowe informacje

Narz�dzia udost�pniane s� bezp�atnie i bez jakiejkolwiek gwarancji dzia�ania
i wsparcia technicznego.
Dozwolone jest u�ywanie, rozpowszechnianie oraz wszelkie modyfikacje
pod warunkiem niepobierania op�at oraz do��czenia informacji o autorstwie.

Wi�cej informacji nt. dzia�ania narz�dzi - w komentarzach kodu �r�d�owego
plik�w SQL.
